---MODELADO FINAL-----
-- LLAVES PRIMARIAS (Identificadores �nicos)
ALTER TABLE productos_clean     ADD CONSTRAINT PK_Prod PRIMARY KEY (producto_id);
ALTER TABLE clientes_clean      ADD CONSTRAINT PK_Cli  PRIMARY KEY (cliente_id);
ALTER TABLE ordenes_clean       ADD CONSTRAINT PK_Ord  PRIMARY KEY (orden_id);
ALTER TABLE detalle_orden_clean ADD CONSTRAINT PK_Det  PRIMARY KEY (linea_id);
-- Nota: Inventario no suele llevar PK si un producto est� en varias bodegas, 
-- pero lo conectamos por su producto_id.

-- LLAVES FOR�NEAS (Los cables que unen las 5 tablas)

-- CLIENTES con ORDENES
ALTER TABLE ordenes_clean 
ADD CONSTRAINT FK_Ord_Cli FOREIGN KEY (cliente_id) REFERENCES clientes_clean(cliente_id);

-- ORDENES con DETALLE_ORDEN
ALTER TABLE detalle_orden_clean 
ADD CONSTRAINT FK_Det_Ord FOREIGN KEY (orden_id) REFERENCES ordenes_clean(orden_id);

-- PRODUCTOS con DETALLE_ORDEN
ALTER TABLE detalle_orden_clean 
ADD CONSTRAINT FK_Det_Prod FOREIGN KEY (producto_id) REFERENCES productos_clean(producto_id);

-- PRODUCTOS con INVENTARIO
ALTER TABLE inventario_clean 
ADD CONSTRAINT FK_Inv_Prod FOREIGN KEY (producto_id) REFERENCES productos_clean(producto_id);

