CREATE DATABASE PORTAFOLIO_2;
USE PORTAFOLIO_2;


SELECT * FROM detalle_orden_raw ORDER BY cantidad ASC;
SELECT 
    COUNT(*) TotalRegistros, --3080
    COUNT(DISTINCT CONCAT(orden_id,'-',producto_id)) AS VALORESUNICOS, --3043
    COUNT(*)- COUNT(DISTINCT CONCAT(orden_id,'-',producto_id)) AS DUPLICADOS -- 37 
FROM detalle_orden_raw;

SELECT d.*
FROM detalle_orden_raw d
JOIN (
    SELECT orden_id, producto_id
    FROM detalle_orden_raw
    GROUP BY orden_id, producto_id
    HAVING COUNT(*) > 1
) dup
ON d.orden_id = dup.orden_id
   AND d.producto_id = dup.producto_id;

---Aunque se detectaron m�ltiples l�neas con la misma combinaci�n Orden�Producto, el an�lisis identific� que no se trataba de duplicados,
--sino de eventos contables v�lidos como ajustes de precio, notas cr�dito parciales o correcciones operativas
--Se plantea realizar una linea_id como llave tecnica unica

SELECT ------------------------------------------------------------------- ESPACIOS AL FINAL Y AL INICIO 
	SUM(CASE WHEN orden_id IS NULL OR LTRIM(RTRIM(orden_id))=' ' THEN 1 END)NULOSORDEN_ID,--0
	SUM(CASE WHEN producto_id IS NULL OR LTRIM(RTRIM(producto_id))=' ' THEN 1 END)NULOS_PRODUCTOID,--0
	SUM(CASE WHEN cantidad IS NULL OR LTRIM(RTRIM(cantidad))=' ' THEN 1 END)NULOSCANTIDAD,--0
    SUM(CASE WHEN precio_unitario_transaccion IS NULL OR LTRIM(RTRIM(precio_unitario_transaccion))=' ' THEN 1 END)NULOSPU,--0
    SUM(CASE WHEN descuento_porcentaje IS NULL OR LTRIM(RTRIM(descuento_porcentaje))=' ' THEN 1 END)NULOSPORCENTAJE,--0
    SUM(CASE WHEN motivo_descuento IS NULL OR LTRIM(RTRIM(motivo_descuento))=' ' THEN 1 END)NULOSMOTIVO_DESCUENTO--629 NULOS
FROM detalle_orden_raw;


SELECT * FROM detalle_orden_raw WHERE motivo_descuento IS NULL;

SELECT 
    descuento_porcentaje,
    COUNT(*) AS registros,
    SUM(CASE WHEN motivo_descuento IS NULL THEN 1 ELSE 0 END) AS nulos_motivo
FROM detalle_orden_raw
GROUP BY descuento_porcentaje
ORDER BY descuento_porcentaje;

--Se identifican valores nulos sin motivo asi que se plantea categorizarlos en 3 partes, venta estandar cant y descuento>0, cantidad>0 y descuento>0 Descuento no Justificado
-- cantidad <0 Ajuste/devolucion, cantidad = ajuste

Select 
    MAX(precio_unitario_transaccion)MaxPU,
    MIN(precio_unitario_transaccion)MinPU
FROM detalle_orden_raw;--- VARIABLE NO COMO NUMERO TIENE VALORES 55,USD EJEMPLO

SELECT DISTINCT precio_unitario_transaccion FROM detalle_orden_raw;

SELECT 
    COUNT(*) total_registros,
    SUM(CASE WHEN precio_unitario_transaccion LIKE '%USD%' THEN 1 ELSE 0 END) con_USD,---25
    SUM(CASE WHEN precio_unitario_transaccion NOT LIKE '%USD%' THEN 1 ELSE 0 END)  sin_USD --3055
FROM detalle_orden_raw;
---SOLUCION SELECCIONAR LOS 25 Y ELIMINAR USD LUEGO CONVERTIRLO EN DECIMAL LUEGO DE ESO VEREMOS SI TIENE VALORES NEGATIVOS Y SE HARA LA CORRECCION

Select 
    MAX(descuento_porcentaje)MaxPU,--20
    MIN(descuento_porcentaje)MinPU--0
FROM detalle_orden_raw; --CORRECTO TAMPOCO TIENE NULOS

SELECT COUNT(*) AS registros_cantidad_cero 
FROM detalle_orden_raw 
WHERE cantidad = 0;

SELECT * FROM detalle_orden_raw WHERE cantidad =0;

--DIAGNOSTICO CLIENTES_RAW---------------------------------------------------------------------------------------------------------------

SELECT * FROM clientes_raw;

SELECT 
    COUNT(*) TotalRegistros, --358 registros
    COUNT(DISTINCT cliente_id)RegistrosUnicos, --350
    COUNT(*) - COUNT(DISTINCT cliente_id)Duplicados -- 8 dupicados
FROM clientes_raw;

SELECT c.*
FROM clientes_raw c
JOIN(
    SELECT
        cliente_id
    FROM clientes_raw
    GROUP BY cliente_id
    HAVING COUNT(*)>1
) dup
    ON c.cliente_id = dup.cliente_id
ORDER BY c.cliente_id;

--ELIMINAR DUPLICADOS YA QUE SON DATOS REPETIDOS--------------------------------------------------

SELECT
    SUM(CASE WHEN cliente_id IS NULL OR LTRIM(RTRIM(cliente_id))=' ' THEN 1 END)NULOSCLIENTEID,--0
    SUM(CASE WHEN nombre_cliente IS NULL OR LTRIM(RTRIM(nombre_cliente))=' ' THEN 1 END)NULOSCLIENTE,--0
    SUM(CASE WHEN ciudad IS NULL OR LTRIM(RTRIM(ciudad))=' ' THEN 1 END)NULOSCIUDAD, --- NULOS 5 CIUDAD 
    SUM(CASE WHEN segmento IS NULL OR LTRIM(RTRIM(segmento))=' ' THEN 1 END)NULOSEGMENTO,--0
    SUM(CASE WHEN fecha_registro IS NULL OR LTRIM(RTRIM(fecha_registro))=' ' THEN 1 END)NULOSREGISTRO--0
 FROM clientes_raw;

 --NULOS EN CIUDAD PONER CATEGORIA DESCONOCIDA
---DIAGNOSTICO FECHA REGISTRO----------------------------------------------------------

SELECT 
    MAX(fecha_registro) AS FechaMaxima, --OK 01-2023
    MIN(fecha_registro) AS FechaMinima -- 12-2023
FROM clientes_raw;

--DIAGNOSTICO TABLA ORDENES_RAW----------------------------------------------------------------
SELECT * FROM ordenes_raw;

SELECT 
    COUNT(*)TotalResgistros,
    COUNT(DISTINCT orden_id)RegistrosUnicos,
    COUNT(*)- COUNT(DISTINCT orden_id)duplicados
FROM ordenes_raw;
----DUPLICADOS 0-------------------------------------------

SELECT
    SUM(CASE WHEN orden_id IS NULL OR LTRIM(RTRIM(orden_id))=' ' THEN 1 END)NULOS,--0
    SUM(CASE WHEN  cliente_id IS NULL OR LTRIM(RTRIM(cliente_id))=' ' THEN 1 END)NULOSclien,--0
    SUM(CASE WHEN  fecha_orden IS NULL OR LTRIM(RTRIM(fecha_orden))=' ' THEN 1 END)NULOSORDEN,--0
    SUM(CASE WHEN  canal_venta IS NULL OR LTRIM(RTRIM(canal_venta))=' ' THEN 1 END)NULOSCANAL,--0
    SUM(CASE WHEN  estado_orden IS NULL OR LTRIM(RTRIM(estado_orden))=' ' THEN 1 END)NULOSorden--0
FROM ordenes_raw;

SELECT DISTINCT canal_venta FROM ordenes_raw;--OK
SELECT DISTINCT estado_orden FROM ordenes_raw;--0K

SELECT
    MAX(fecha_orden)maximo,--2025-01-14
    MIN(fecha_orden)minimo--2023-12-22
FROM ordenes_raw;

---DIAGNOSTICO INVENTARIO RAW -------------------------------------
SELECT * FROM inventario_raw ORDER BY producto_id DESC;

SELECT 
    COUNT(*)TotalRegistros,
    COUNT(DISTINCT CONCAT(producto_id, '-' ,bodega)) AS ValoresUnicos,
    COUNT(*) - COUNT(DISTINCT CONCAT(producto_id, '-' ,bodega)) AS Duplicados
FROM inventario_raw;

SELECT 
    MIN(stock_actual)MINI,-- (-3)
    MAX(stock_actual)MAXI--(218)
FROM inventario_raw;

SELECT * FROM inventario_raw WHERE stock_actual < 0; --16,18,91,108 estos productos no quiere decir que este mal sino que faltan en el inventario y no esta
--porque el producto esta en otras bodegas
--- en el tabletro tener en cuenta stock vs punto de reorden puede haber sobre stock en unas bodegas

SELECT * FROM inventario_raw WHERE producto_id IN (16,18,91,108);

SELECT 
    MIN(punto_reorden)MINI,-- (10)
    MAX(punto_reorden)MAXI--(331)
FROM inventario_raw;

SELECT * FROM inventario_raw WHERE stock_actual > punto_reorden ORDER BY stock_actual DESC; -- se evidencia sobrestock en algunos productos
--verificar ventas de los productos vs stock yy punto de reorden

SELECT DISTINCT bodega FROM inventario_raw;

---DIAGNOSTICO CATALOGO PRODUCTOS-------------------------------------------

SELECT * FROM productos_raw;

SELECT
    COUNT(*) TotalRegistros,
    COUNT(DISTINCT CONCAT(producto_id,'-',nombre_producto)) AS ValoresUnicos,
    COUNT(*)-COUNT(DISTINCT CONCAT(producto_id,'-',nombre_producto)) AS Duplicados
FROM productos_raw;----DUPLICADOS 0

SELECT DISTINCT categoria FROM productos_raw; --ERROR DIGITACION ACCESORIO - ACCESOSRIOS COREEGIR
--PONER ACCESORIOS

SELECT
    SUM(CASE WHEN categoria IS NULL OR LTRIM(RTRIM(categoria))=' ' THEN 1 END)NULOS,--0
    SUM(CASE WHEN  nombre_producto IS NULL OR LTRIM(RTRIM(nombre_producto))=' ' THEN 1 END)NULOSPROD--0
FROM productos_raw;----ambos NULL

SELECT precio_lista FROM productos_raw
WHERE precio_lista < 0;

SELECT
    MAX(precio_lista)MAXIMO,--148.83
    MIN(precio_lista)MINIMO--25.94
FROM productos_raw;

SELECT
    MAX(costo_unitario)MAXIMO,--89.51
    MIN(costo_unitario)MINIMO--11.45
FROM productos_raw;


