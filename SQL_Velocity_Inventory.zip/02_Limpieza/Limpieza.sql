--LIMPIEZA DETALLE_ORDEN_RAW----------------
SELECT 
    IDENTITY(INT, 1, 1) AS linea_id, -- Aqu� est� la magia: auto-incremental desde 1
    orden_id,
    producto_id,
    cantidad,
    CAST(REPLACE(precio_unitario_transaccion, 'USD', '') AS DECIMAL(10,2)) AS precio_unitario,
    descuento_porcentaje,
    CASE 
        WHEN motivo_descuento IS NOT NULL THEN motivo_descuento
        WHEN cantidad < 0 THEN 'Ajuste/Devoluci�n'
        WHEN cantidad = 0 THEN 'Ajuste Contable'
        WHEN descuento_porcentaje > 0 THEN 'Descuento No Justificado'
        ELSE 'Venta Est�ndar'
    END AS motivo_descuento_clean
INTO detalle_orden_clean
FROM detalle_orden_raw;

-- 3. Ahora s� definimos la llave primaria (sin errores)
ALTER TABLE detalle_orden_clean 
ADD CONSTRAINT PK_Det PRIMARY KEY (linea_id);

--LIMPIEZA clientes_raw-----------------------
--Crear la tabla clientes_clean como copia exacta de clientes_raw
IF OBJECT_ID('clientes_clean', 'U') IS NOT NULL DROP TABLE clientes_clean;

SELECT *
INTO clientes_clean
FROM clientes_raw;

-- Guardamos solo los registros �nicos en una tabla temporal
SELECT 
    cliente_id, 
    MAX(nombre_cliente) as nombre_cliente, 
    MAX(ciudad) as ciudad, 
    MAX(segmento) as segmento, 
    MAX(fecha_registro) as fecha_registro
INTO #Temporales
FROM clientes_clean
GROUP BY cliente_id;

-- Limpiamos nuestra tabla clientes_clean y le metemos los datos �nicos
TRUNCATE TABLE clientes_clean;

INSERT INTO clientes_clean
SELECT * FROM #Temporales;

-- Borramos la tabla temporAL
DROP TABLE #Temporales;

-- Cambiamos los nulos o vac�os por 'Desconocida'
UPDATE clientes_clean
SET ciudad = 'Desconocida'
WHERE ciudad IS NULL OR LTRIM(RTRIM(ciudad)) = '';

--VERIFICACION
SELECT 
    COUNT(*) AS Total_Registros, -- Debe ser 350
    SUM(CASE WHEN ciudad = 'Desconocida' THEN 1 ELSE 0 END) AS Ciudades_Corregidas -- Debe ser 5
FROM clientes_clean;

----LIMPIEZA INVENTARIO_RAW---------------------
IF OBJECT_ID('inventario_clean', 'U') IS NOT NULL DROP TABLE inventario_clean;

SELECT *
INTO inventario_clean
FROM inventario_raw;

-- Verificamos la creaci�n
SELECT COUNT(*) AS Total_Inventario FROM inventario_clean;

-----CLASIFICACION--------------------------------
-- Agregamos una nueva columna para el an�lisis

ALTER TABLE inventario_clean ADD estado_stock VARCHAR(50);

-- Llenamos la columna con l�gica de negocio
UPDATE inventario_clean
SET estado_stock = CASE 
    WHEN stock_actual < 0 THEN 'Quiebre / Reserva'
    WHEN stock_actual = 0 THEN 'Sin Stock'
    WHEN stock_actual <= punto_reorden THEN 'Reponer Urgente'
    WHEN stock_actual > (punto_reorden * 2) THEN 'Exceso / Sobrestock'
    ELSE 'Stock Saludable'
END;

--VERIFICACION----
SELECT estado_stock, COUNT(*) AS Total_Productos
FROM inventario_clean
GROUP BY estado_stock
ORDER BY Total_Productos DESC;

--LIMPIEZA PRODUCTOS RAW-----------
IF OBJECT_ID('productos_clean', 'U') IS NOT NULL DROP TABLE productos_clean;

SELECT *
INTO productos_clean
FROM productos_raw;

SELECT DISTINCT categoria FROM productos_raw;

-- Unificamos todas las variantes detectadas
UPDATE productos_clean
SET categoria = 'Accesorios'
WHERE categoria IN ('Acces�rio', 'Accesorios', 'ACCESOSRIOS', 'ACCESORIO');

-- Verificaci�n final
SELECT categoria, COUNT(*) AS Total
FROM productos_clean
GROUP BY categoria
ORDER BY categoria;

----LIMPIEZA ORDENES RAW------------------------
IF OBJECT_ID('ordenes_clean', 'U') IS NOT NULL DROP TABLE ordenes_clean;

SELECT 
    orden_id,
    cliente_id,
    CAST(fecha_orden AS DATE) AS fecha_orden, 
    canal_venta,
    estado_orden
INTO ordenes_clean
FROM ordenes_raw;